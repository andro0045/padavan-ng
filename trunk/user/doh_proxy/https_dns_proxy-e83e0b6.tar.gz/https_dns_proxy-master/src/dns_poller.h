#ifndef _DNS_POLLER_H_
#define _DNS_POLLER_H_

#include <ares.h>
#include <ev.h>

// Fast DNS querying mode
// Requests will be send after 0, 0.8, 1.3, 1.75 second
// And waiting extra 4.2 seconds for reply
// That's total: 8,05 second for trying
#define POLLER_QUERY_TIMEOUT_MS 700
#define POLLER_QUERY_TRIES 4

// enough for minimum 64 pcs IPv4 address or 25 pcs IPv6
#define POLLER_ADDR_LIST_SIZE 1024

// Callback to be called periodically when we get a valid DNS response.
typedef void (*dns_poller_cb)(const char* hostname, void *data,
                              const char *addr_list);

typedef struct dns_io_event {
  ev_io watcher;
  struct dns_io_event *next;
} dns_io_event_t;

typedef struct {
  ares_channel ares;
  struct ev_loop *loop;
  char *hostname;  // owned; strdup'd in init, freed in cleanup
  char *outbound_interface;  // owned; optional interface used by socket callback
  int family;  // AF_UNSPEC for IPv4 or IPv6, AF_INET for IPv4 only.
  dns_poller_cb cb;
  int polling_interval;
  int request_ongoing;
  void *cb_data;

  ev_timer timer;
  dns_io_event_t *io_events;
} dns_poller_t;

// Initializes c-ares and starts a timer for periodic DNS resolution on the
// provided ev_loop. `bootstrap_dns` is a comma-separated list of DNS servers to
// use for the lookup `hostname` every `interval_seconds`. For each successful
// lookup, `cb` will be called with the resolved address.
// `source_addr` optionally binds bootstrap DNS lookups to a specific IP and
// `outbound_interface` optionally binds them to a Linux network interface.
// `family` should be AF_INET for IPv4 or AF_UNSPEC for both IPv4 and IPv6.
//
// Note: hostname and outbound_interface are copied; the caller's buffers need
// not outlive this call.
void dns_poller_init(dns_poller_t *d, struct ev_loop *loop,
                     const char *bootstrap_dns,
                     int bootstrap_dns_polling_interval,
                     const char *source_addr,
                     const char *outbound_interface,
                     const char *hostname,
                     int family, dns_poller_cb cb, void *cb_data);

// Tears down timer and frees resources associated with a dns poller.
void dns_poller_cleanup(dns_poller_t *d);

#endif
